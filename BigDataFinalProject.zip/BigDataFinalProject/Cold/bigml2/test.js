var getT = require('./bigml2/associationTable');


var x = getT
console.log(x);